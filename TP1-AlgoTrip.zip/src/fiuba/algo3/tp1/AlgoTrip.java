package fiuba.algo3.tp1;

public class AlgoTrip {

}
